const makermenu = (prefix) => { 
	return `
╔══✪〘 MAKER 〙✪══*[NEW Fitur]*
║
╰─⊱ *${prefix}lava* [text]
Usage : ${prefix}lava AnggaPutraJN [Masukkan nama kalian atau bebas mau text apa aja]
╰─⊱ *${prefix}firework* [text]
Usage : ${prefix}firework AnggaPutraJN [Masukkan nama kalian atau bebas mau text apa aja]
╰─⊱ *${prefix}blood* [text]
Usage : ${prefix}blood AnggaPutraJN [Masukkan nama kalian atau bebas mau text apa aja]
╰─⊱ *${prefix}sumery* [text]
Usage : ${prefix}sumery AnggaPutraJN [Masukkan nama kalian atau bebas mau text apa aja]
╰─⊱ *${prefix}toxic2* [text]
Usage : ${prefix}toxic2 AnggaPutraJN [Masukkan nama kalian atau bebas mau text apa aja]
╰─⊱ *${prefix}neontext* [text]
Usage : ${prefix}neontext AnggaPutraJN [Masukkan nama kalian atau bebas mau text apa aja]
╰─⊱ *${prefix}grenneon* [text]
Usage : ${prefix}grenneon AnggaPutraJN [Masukkan nama kalian atau bebas mau text apa aja]
╰─⊱ *${prefix}dropwater* [text]
Usage : ${prefix}dropwater AnggaPutraJN [Masukkan nama kalian atau bebas mau text apa aja]
╰─⊱ *${prefix}metaldark* [text]
Usage : ${prefix}metaldark AnggaPutraJN [Masukkan nama kalian atau bebas mau text apa aja]
╰─⊱ *${prefix}sandwrite* [text]
Usage : ${prefix}sandwrite AnggaPutraJN [Masukkan nama kalian atau bebas mau text apa aja]
╰─⊱ *${prefix}summer* [text]
Usage : ${prefix}summer AnggaPutraJN [Masukkan nama kalian atau bebas mau text apa aja]
╰─⊱ *${prefix}shadow* [text]
Usage : ${prefix}shadow AnggaPutraJN [Masukkan nama kalian atau bebas mau text apa aja]
║
╚═〘 BOT INDapk © 2021 〙`
}
exports.makermenu = makermenu