const menurom = (prefix) => { 
	return `
╔══✪〘 ROM EMULATOR 〙✪════════════
║		*[NEW Fitur]*
╠═══════════════════════════
╠➥ *${prefix}ppsspp*
╠➥ *${prefix}ppssppringan*
╠➥ *${prefix}ps1*
╠➥ *${prefix}ps2*
╠➥ *${prefix}gamecube*
╠➥ *${prefix}wii*
╠═══════════════════════════
〘  BOT INDapk 〙

	`
}
exports.menurom = menurom