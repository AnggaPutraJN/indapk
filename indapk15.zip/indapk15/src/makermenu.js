const makermenu = (prefix) => { 
	return `
╔══✪〘 MAKER 〙✪══*[NEW Fitur]*
║
╰─⊱ *${prefix}shadow* [text]
╰─⊱ *${prefix}lava* [text]
╰─⊱ *${prefix}firework* [text]
╰─⊱ *${prefix}blood* [text]
╰─⊱ *${prefix}sumery* [text]
╰─⊱ *${prefix}toxic2* [text]
╰─⊱ *${prefix}neontext* [text]
╰─⊱ *${prefix}grenneon* [text]
╰─⊱ *${prefix}dropwater* [text]
╰─⊱ *${prefix}metaldark* [text]
╰─⊱ *${prefix}sandwrite* [text]
╰─⊱ *${prefix}summer* [text]
╰─⊱ *${prefix}shadow* [text]
║
╚═〘  BOT INDapk 〙`
}
exports.makermenu = makermenu