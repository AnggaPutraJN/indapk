const menurom = (prefix) => { 
	return `
╔══✪〘 ROM EMULATOR 〙✪════════════
║
╠═══════════════════════════
╠➥ *${prefix}ppsspp*
╠➥ *${prefix}wii*
╠═══════════════════════════
〘  BOT INDapk 〙

	`
}
exports.menurom = menurom