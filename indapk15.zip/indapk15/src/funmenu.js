const funmenu = (prefix) => { 
	return `
✎═─⊱〘 𝐹𝑈𝑁 𝑀𝐸𝑁𝑈 〙⊰══
║
╰─⊱ *${prefix}truth*
╰─⊱ *${prefix}dare*
╰─⊱ *${prefix}simi* [text]
╰─⊱ *${prefix}gtts* [text]
╰─⊱ *${prefix}tts*
║
✎═─⊱〘 BOT INDapk 〙⊰══`
}
exports.funmenu = funmenu