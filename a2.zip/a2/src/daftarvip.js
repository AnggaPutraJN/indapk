const daftarvip = (prefix) => { 
	return `
	
*Owner BOT :*
_wa.me/082286344446 atau ketik *${prefix}owner*

*GRUP WHATSAPP BOT :*
°Whatsapp Game : _https://chat.whatsapp.com/Et6CVorLr5D3ILDkMlE6jW_

°Whatsapp Doujin 1 : _https://chat.whatsapp.com/G4P1tpV1MNd67efeMAEoof_

°Whatsapp Doujin 2 : _https://chat.whatsapp.com/GddnwqWKVzSLhrr9ikY9wE_


*Situs :*
_https://www.indapk.com_

╔══✪〘 BUY VIP 〙✪═══════════
║➤${prefix}buyvip
║➤Deskripsi :gunakan command diatas untuk beli Full Akses Bot
╠════════════════════════════
║
╚═〘 BOT INDapk © 2021 〙
 `
}
exports.daftarvip = daftarvip