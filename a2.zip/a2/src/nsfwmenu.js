const nsfwmenu = (prefix) => { 
	return `
╔══✪〘 NSFW 〙✪══
║
║
╰─⊱  *${prefix}nsfw*
Usage : ${prefix}nsfw [1/0]
Deskripsi : Untuk mengaktifkan fitur nsfw angka 1 untuk aktifkan, dan angka 0 untuk nonaktif
╰─⊱ *${prefix}randomhentai* _[Fitur khusus VIP]_
Usage : ${prefix}randomhentai
╰─⊱ *${prefix}hentai* _[Fitur khusus VIP]_
Usage : ${prefix}hentai
╰─⊱ *${prefix}blowjob* _[Fitur khusus VIP]_
Usage : ${prefix}blowjob
╰─⊱ *${prefix}nsfwtrap* _[Fitur khusus VIP]_
Usage : ${prefix}nsfwtrap _[Fitur khusus VIP]_
╰─⊱ *${prefix}kodenuklir2*
Usage : ${prefix}kodenuklir2
╰─⊱ *${prefix}kodenuklir*
Usage : ${prefix}kodenuklir
╰─⊱ *${prefix}nekopoi* _[Fitur khusus VIP]_
Usage : ${prefix}nekopoi
╰─⊱  *${prefix}indo(1-25)* __[Fitur khusus VIP]__
Usage : ${prefix}indo23 [Masukkan angkanya 1 sampai 25]

╔══✪〘 BUY VIP 〙✪═══════════
║➤${prefix}buyvip
║➤Deskripsi :gunakan command diatas untuk beli Full Akses Bot
╠════════════════════════════
║
╚═〘 BOT INDapk © 2021 〙`
}
exports.nsfwmenu = nsfwmenu