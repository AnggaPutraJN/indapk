const buyvip = () => { 
	return `
╔══✪〘 *HARGA VIP* 〙✪════
║➤ FULL AKSES VIP 15K (Sudah termasuk masukin bot kedalam grup)
║➤ MASUKIN BOT KE GRUP 10K
║➤ Via Gopay : *6282286344446*
║➤ Via Dana : *6282286344446*
║➤ Botnya akan update terus kok, User VIP bisa akses langsung nanti fitur2 baru yg akan update
║➤ Bot akan Aktif 24jam
║➤ Tiap hari bot akan share minimal 1 link game
║➤ Untuk pesan Akses VIP nya, bisa ketik command *${prefix}owner* , silahkan pesan langsung ke ownernya kak!
║➤ Report Bug : *${prefix}reportbug*
╠═══✪〘 OWNER 〙✪════
║➤ _wa.me/082286344446_ atau ketik *${prefix}owner*
║➤ Join Group 1 Owner : https://chat.whatsapp.com/Et6CVorLr5D3ILDkMlE6jW
║➤ Join Group 2 Owner : https://chat.whatsapp.com/GddnwqWKVzSLhrr9ikY9wE
║➤ Join Group 3 Owner : https://chat.whatsapp.com/G4P1tpV1MNd67efeMAEoof
╚➤〘 BOT INDapk © 2021 〙`
}
exports.buyvip = buyvip
