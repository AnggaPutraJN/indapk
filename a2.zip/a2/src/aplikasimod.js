const aplikasimod = (prefix) => { 
	return `
╔══✪〘 APK MOD 〙✪════════════
║
╠➥ *${prefix}emulator*
Usage : ${prefix}emulator
╠➥ *${prefix}aplikasi*
Usage : ${prefix}aplikasi
╠═══════════════════════════
〘  BOT INDapk 〙

╔══✪〘 BUY VIP 〙✪═══════════
║➤${prefix}buyvip
║➤Deskripsi :gunakan command diatas untuk beli Full Akses Bot
╠════════════════════════════
	`
}
exports.aplikasimod = aplikasimod