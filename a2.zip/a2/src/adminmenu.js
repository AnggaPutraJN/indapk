const adminmenu = (prefix) => { 
	return `
✎═─⊱〘 𝐴𝐷𝑀𝐼𝑁 𝑀𝐸𝑁𝑈 〙⊰══
║
║
╰─⊱  *${prefix}setdesc*
Usage : ${prefix}setdesc Masukkan Teksnya Untuk mengubah deskripsi grup
╰─⊱  *${prefix}setname*
Usage : ${prefix}setname Masukkan Teksnya Untuk mengubah nama grup
╰─⊱  *${prefix}kick* [tag]
Usage : ${prefix}kick Tag Member yang ingin di kick
╰─⊱  *${prefix}add* [628xxx]
Usage : ${prefix}add 628xxx Masukin nomor target
╰─⊱  *${prefix}demote* [tag]
Usage : ${prefix}demote Tag admin untuk tidak dijadikan admin lagi
╰─⊱  *${prefix}group* [buka]
Usage : ${prefix}group buka
╰─⊱  *${prefix}group* [tutup]
Usage : ${prefix}group tutup
╰─⊱  *${prefix}setpp*
Usage : ${prefix}setpp Upload gambar yg ingin dijadikan icon group!
╰─⊱  *${prefix}simih* [1/0]
Usage : ${prefix}simih 1 untuk mengaktifkan fitur simih dan ${prefix}simih 0 untuk nonaktifkan fitur
╰─⊱  *${prefix}welcome* [1/0]
Usage : ${prefix}welcome 1 Untuk mengaktifkan welcome pada grup dan ${prefix}welcome 0 untuk menonaktifkan
╰─⊱  *${prefix}listadmin*
Usage : ${prefix}listadmin

║
║
✎═─⊱〘 BOT INDapk © 2021 〙⊰══`
}
exports.adminmenu = adminmenu