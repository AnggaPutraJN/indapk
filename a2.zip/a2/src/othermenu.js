const othermenu = (prefix) => { 
	return `
╔══✪〘 OTHER 〙✪══
║
╰─⊱ *${prefix}s [replay gambar]*
Usage : ${prefix}s Replay gambar atau masukin gambar
╰─⊱ *${prefix}toimg [replay sticker]*
Usage : ${prefix}toimg Replay Stickernya
╰─⊱  *${prefix}tagme*
Usage : ${prefix}tagme
╰─⊱  *${prefix}groupinfo*
Usage : ${prefix}groupinfo
╰─⊱  *${prefix}infogc*
Usage : ${prefix}infogc
╰─⊱  *${prefix}linkgc*
Usage : ${prefix}linkgc
╰─⊱ *${prefix}dadu*
Usage : ${prefix}dadu
╰─⊱ *${prefix}ocr [gambar]*
Usage : ${prefix}ocr [Masukin gambarnya]
╰─⊱ *${prefix}meme*
Usage : ${prefix}meme
╰─⊱ *${prefix}testime*
Usage : ${prefix}testime
╰─⊱ *${prefix}hobby*
Usage : ${prefix}hobby Masukkan teksnya
╰─⊱ *${prefix}slap*
Usage : ${prefix}slap
╰─⊱ *${prefix}beritahoax*
Usage : ${prefix}beritahoax
╰─⊱ *${prefix}watak*
Usage : ${prefix}watak
╰─⊱ *${prefix}artinama* [nama]
Usage : ${prefix}artinama anggaputrajn [Masukin nama]
╰─⊱ *${prefix}listsurah*
Usage : ${prefix}listsurah
╰─⊱ *${prefix}fitnah [@tag|pesan|balasanbot]*
Usage : ${prefix}fitnah Tag|Pesannya|Balasan botnya
╰─⊱ *${prefix}premiumlist*
Usage : ${prefix}premiumlist
╰─⊱ *${prefix}tentangindapk*
Usage : ${prefix}tentangindapk
╰─⊱ *${prefix}iklan*
Usage : ${prefix}iklan
╰─⊱ *${prefix}runtime*
Usage : ${prefix}runtime
╰─⊱ *${prefix}infonomor*
Usage : ${prefix}infonomor 082286344446 [Masukkan nomornya]
╰─⊱ *${prefix}wame*
Usage : ${prefix}wame
╰─⊱ *${prefix}indapk*
Usage : ${prefix}indapk
╰─⊱ *${prefix}indmangapdf*
Usage : ${prefix}indmangapdf
╰─⊱ *${prefix}indmangapdf2*
Usage : ${prefix}indmangapdf2
║
╠═══✪〘 ANIMALS 〙✪══
║
╰─⊱ *${prefix}anjing*
Usage : ${prefix}anjing
║
╚═ Ketik *${prefix}kegunaanbot* untuk melihat list informasi tentang bot
   Ketik *${prefix}owner* untuk melihat kontak owner
   Mau donasi? 082286344446(Gopay)
   Jika tidak ingin donasi bantu Follow Ig aja kak 
   _instagram.com/indapk
║
╚═〘 BOT INDapk © 2021 〙`
}
exports.othermenu = othermenu