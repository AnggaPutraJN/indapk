const iklan = () => { 
	return `           
╔══✪〘 IKLAN 〙✪════════════
╠Yang ingin memasang iklan di BOT INDapk atau memasang iklan di situs https://indapk.com , bisa hubungi owner bot ini, dengan ketik ${prefix}owner
╚═
╔══✪〘 BUY VIP 〙✪═══════════
║➤${prefix}buyvip
║➤Deskripsi :gunakan command diatas untuk beli Full Akses Bot
╠════════════════════════════
〘  BOT INDapk 〙
`
}
exports.iklan = iklan