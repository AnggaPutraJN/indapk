const gamingmenu = (prefix) => { 
	return `
╔══✪〘 GAMING ROOM 〙✪══════════
║
╠➥ *${prefix}menurom*
║Usage : ${prefix}menurom
╠➥ *${prefix}gamemod*
║Usage : ${prefix}gamemod
╠➥Comingsoon
╠══✪〘 REQUEST GAME 〙✪══════════
╠➥ *${prefix}requestgame*
╠═══════════════════════════
〘 BOT INDapk © 2021 〙

	`
}
exports.gamingmenu = gamingmenu