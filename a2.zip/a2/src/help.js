const help = (prefix) => { 
	return `
╔══✪〘 BUY VIP 〙✪═══════════
║➤${prefix}buyvip
║➤Deskripsi :gunakan command diatas untuk beli Full Akses Bot


═════✪〘 VIP MENU 〙✪═══════════
╰─⊱  *${prefix}bcgc*
Usage : ${prefix}bcgc [Pesan yg ingin dimasukkan]
Deskripsi : Untuk chat kesemua member grup
╰─⊱  *${prefix}scan*
Usage : ${prefix}scan [Upload screesnhot anime yang ingin di scan]
Deskripsi : Untuk scan ss anime, hentai dll, Pastikan gambarnya harus jelas !
╰─⊱  *${prefix}spam50*
Usage : ${prefix}spam50
Deskripsi : Untuk spam grup sebanyak 100
╰─⊱  *${prefix}spam20*
Usage : ${prefix}spam20
Deskripsi : Untuk spam grup sebanyak 20
╰─⊱  *${prefix}spam5*
Usage : ${prefix}spam5
Deskripsi : Untuk spam grup sebanyak 5
╰─⊱  *${prefix}spam2*
Usage : ${prefix}spam2
Deskripsi : Untuk spam grup sebanyak 2
╰─⊱  *${prefix}bannedmember*
Usage : ${prefix}bannedmember Tag namanya
Deskripsi : Untuk banned member dari list bot
╰─⊱  *${prefix}setppbot*
╰─⊱  *${prefix}unban*
Usage : ${prefix}unban Tag nama yg sudah dibanned
Deskripsi : Untuk melepas banned member dari list bot
╰─⊱  *${prefix}setppbot*
Usage : ${prefix}setppbot
Deskripsi : Untuk mengubah foto profile bot
╰─⊱  *${prefix}tagall*
Usage : ${prefix}tagall
Deskripsi : Untuk tag semua member
╰─⊱  *${prefix}tomp3*
Usage : ${prefix}tomp3 [Reply videonya]
Deskripsi : Untuk mengubah Video Ke MP3
╰─⊱  *${prefix}joox*
Usage : ${prefix}joox [Masukkan judul lagunya]
Deskripsi : Untuk Download Musik
╰─⊱  *${prefix}lirik*
Usage : ${prefix}lirik [Masukkan judul lagunya]
Deskripsi : Untuk Cek Lirik Musik
╰─⊱  *${prefix}promote*
Usage : ${prefix}promote [Tag namanya]
Deskripsi : Untuk menjadikan admin grup, Pastikan BOTnya harus admin grup dulu!
╰─⊱  *${prefix}indo1-25*
Usage : ${prefix}indo1-25 (26- ∞ Comingsoon)
Deskripsi : Untuk download bokep [Nanti owner akan menambahkan lagi]
╰─⊱  *${prefix}nsfw*
Usage : ${prefix}nsfw [1/0]
Deskripsi : Untuk mengaktifkan fitur nsfw angka 1 untuk aktifkan, dan angka 0 untuk nonaktif
╰─⊱  *${prefix}hentai*
Usage : ${prefix}hentai
Deskripsi : Random hentai [∞]
╰─⊱  *${prefix}nsfwtrap*
Usage : ${prefix}nsfwtrap
Deskripsi : Random trap [∞]
╰─⊱  *${prefix}nsfwneko*
Usage : ${prefix}nsfwneko
Deskripsi : Random neko hentai [∞]
╰─⊱  *${prefix}blowjob*
Usage : ${prefix}blowjob
Deskripsi : Random blowjob [∞]
╰─⊱  *${prefix}randomhentai*
Usage : ${prefix}randomhentai
Deskripsi : Random hentai 2 [∞]
╰─⊱  *${prefix}nekopoi*
Usage : ${prefix}nekopoi
Deskripsi : Akses Nekopoi Tanpa VPN
╰─⊱ *${prefix}vn*
Usage : ${prefix}vn id Hai Owner Ganteng
Deskripsi : Voice Note Menggunakan Suara Google Translate, cek kode2 bahasanya di command *${prefix}kodebhs*
╰─⊱ *${prefix}kodebhs*
Usage : ${prefix}kodebhs
Deskripsi : Cek Kode Bahasa
╰─⊱ *${prefix}pinterest*
Usage : ${prefix}pinterest Nama Anime atau hal lainnya yang ingin dicari
Deskripsi : Untuk mencari gambar-gambar di pinterest
║
╠══✪〘 ALL MENU 〙✪═══════════
║
╰─⊱ *${prefix}help*
Usage : ${prefix}help
╰─⊱ *${prefix}menuowner*
Usage : ${prefix}menuowner
╰─⊱ *${prefix}adminmenu*
Usage : ${prefix}adminmenu
╰─⊱ *${prefix}gamingmenu*
Usage : ${prefix}gamingmenu
╰─⊱ *${prefix}nsfwmenu*
Usage : ${prefix}nsfwmenu
╰─⊱ *${prefix}animemenu*
Usage : ${prefix}animemenu
╰─⊱ *${prefix}othermenu*
Usage : ${prefix}othermenu
╰─⊱ *${prefix}makermenu*
Usage : ${prefix}makermenu
╰─⊱ *${prefix}mediamenu*
Usage : ${prefix}mediamenu
╰─⊱ *${prefix}funmenu*
Usage : ${prefix}funmenu
╰─⊱ *${prefix}kerangmenu*
Usage : ${prefix}kerangmenu
║
╠══✪〘 ADMIN 〙✪═══════════
║
╰─⊱  *${prefix}setdesc*
Usage : ${prefix}setdesc Masukkan Teksnya Untuk mengubah deskripsi grup
╰─⊱  *${prefix}setname*
Usage : ${prefix}setname Masukkan Teksnya Untuk mengubah nama grup
╰─⊱  *${prefix}kick* [tag]
Usage : ${prefix}kick Tag Member yang ingin di kick
╰─⊱  *${prefix}add* [628xxx]
Usage : ${prefix}add 628xxx Masukin nomor target
╰─⊱  *${prefix}demote* [tag]
Usage : ${prefix}demote Tag admin untuk tidak dijadikan admin lagi
╰─⊱  *${prefix}group* [buka]
Usage : ${prefix}group buka
╰─⊱  *${prefix}group* [tutup]
Usage : ${prefix}group tutup
╰─⊱  *${prefix}setpp*
Usage : ${prefix}setpp Upload gambar yg ingin dijadikan icon group!
╰─⊱  *${prefix}simih* [1/0]
Usage : ${prefix}simih 1 untuk mengaktifkan fitur simih dan ${prefix}simih 0 untuk nonaktifkan fitur
╰─⊱  *${prefix}welcome* [1/0]
Usage : ${prefix}welcome 1 Untuk mengaktifkan welcome pada grup dan ${prefix}welcome 0 untuk menonaktifkan
╰─⊱  *${prefix}listadmin*
Usage : ${prefix}listadmin
║
╠══✪〘 Gaming Menu 〙✪═══ *[NEW Fitur]*
║
╰─⊱ *${prefix}gamingmenu*
Usage : ${prefix}gamingmenu
╰─⊱ *${prefix}aplikasimod*
Usage : ${prefix}aplikasimod
║
╠══✪〘 FUN 〙✪═══════════
║
╰─⊱ *${prefix}vn [kode bhs] [teks]*
Usage : ${prefix}vn id Owner ganteng [Kode bahasa untuk bahasa Indonesia, Ketik ${prefix}kodebhs untuk cek kode-kode bahasanya]
╰─⊱ *${prefix}kodebhs*
Usage : ${prefix}kodebhs
╰─⊱ *${prefix}truth*
Usage : ${prefix}truth
╰─⊱ *${prefix}dare*
Usage : ${prefix}dare
╰─⊱ *${prefix}pinterest*
Usage : ${prefix}pinterest naruto (masukin aja text bebas)
╰─⊱ *${prefix}syg* [text]
Usage : ${prefix}syg aku ganteng gak [Masukkan text atau pertanyaan]
║
╠══✪〘 KERANG 〙✪═════════
║
╰─⊱ *${prefix}apakah [optional]*
Usage : ${prefix}apakah Masukkan textnya bebas
╰─⊱ *${prefix}rate [optional]*
Usage : ${prefix}rate Masukkan textnya bebas
╰─⊱ *${prefix}bisakah [optional]*
Usage : ${prefix}bisakah Masukkan textnya bebas
╰─⊱ *${prefix}kapankah [optional]*
Usage : ${prefix}kapankah Masukkan textnya bebas
╰─⊱ *${prefix}gantengcek*
Usage : ${prefix}
╰─⊱ *${prefix}toxic*
Usage : ${prefix}toxic
╰─⊱ *${prefix}cantikcek*
Usage : ${prefix}cantikcek
╰─⊱ *${prefix}gay [tag]*
Usage : ${prefix}gay Tag orangnya
║
╠══✪〘 MAKER 〙✪═══════════*[NEW Fitur]*
║
╰─⊱ *${prefix}lava* [text]
Usage : ${prefix}lava AnggaPutraJN [Masukkan nama kalian atau bebas mau text apa aja]
╰─⊱ *${prefix}firework* [text]
Usage : ${prefix}firework AnggaPutraJN [Masukkan nama kalian atau bebas mau text apa aja]
╰─⊱ *${prefix}blood* [text]
Usage : ${prefix}blood AnggaPutraJN [Masukkan nama kalian atau bebas mau text apa aja]
╰─⊱ *${prefix}sumery* [text]
Usage : ${prefix}sumery AnggaPutraJN [Masukkan nama kalian atau bebas mau text apa aja]
╰─⊱ *${prefix}toxic2* [text]
Usage : ${prefix}toxic2 AnggaPutraJN [Masukkan nama kalian atau bebas mau text apa aja]
╰─⊱ *${prefix}neontext* [text]
Usage : ${prefix}neontext AnggaPutraJN [Masukkan nama kalian atau bebas mau text apa aja]
╰─⊱ *${prefix}grenneon* [text]
Usage : ${prefix}grenneon AnggaPutraJN [Masukkan nama kalian atau bebas mau text apa aja]
╰─⊱ *${prefix}dropwater* [text]
Usage : ${prefix}dropwater AnggaPutraJN [Masukkan nama kalian atau bebas mau text apa aja]
╰─⊱ *${prefix}metaldark* [text]
Usage : ${prefix}metaldark AnggaPutraJN [Masukkan nama kalian atau bebas mau text apa aja]
╰─⊱ *${prefix}sandwrite* [text]
Usage : ${prefix}sandwrite AnggaPutraJN [Masukkan nama kalian atau bebas mau text apa aja]
╰─⊱ *${prefix}summer* [text]
Usage : ${prefix}summer AnggaPutraJN [Masukkan nama kalian atau bebas mau text apa aja]
╰─⊱ *${prefix}shadow* [text]
Usage : ${prefix}shadow AnggaPutraJN [Masukkan nama kalian atau bebas mau text apa aja]
║
╠══✪〘 MEDIA 〙✪═══════════
║
╰─⊱ *${prefix}ytkomen* [Nama|Teksnya]
Usage : ${prefix}ytkomen Masukkan nama kalian | Komentar atau Text bebas
╰─⊱ *${prefix}chord* [judul lagu]
Usage : ${prefix}chord Impossible
╰─⊱ *${prefix}url2img* [link]
Usage : ${prefix}url2img Mobile | Linknya [Tipenya ada Desktop, Tablet, Mobile]
╰─⊱ *${prefix}fototiktok* [username]
Usage : ${prefix}fototiktok anggaputrajn [Masukkan id usernamenya]
╰─⊱ *${prefix}map* [kota]
Usage : ${prefix}map Makassar [Masukkan nama kotanya]
╰─⊱ *${prefix}kbbi* [kamus]
Usage : ${prefix}kbbi Masukkan kamusnya
╰─⊱ *${prefix}infocuaca* [kota]
Usage : ${prefix}infocuaca Makassar [Masukkan nama kotanya]
╰─⊱ *${prefix}artinama [nama]*
Usage : ${prefix}artinama anggaputrajn [Masukkan nama]
╰─⊱ *${prefix}resepmasakan [optional]*
Usage : ${prefix}resepmasakan ayam goreng [Bebas]
╰─⊱ *${prefix}tiktokstalk [@username]*
Usage : ${prefix}tiktokstalk anggaputrajn [Masukkan id usernamenya]
╰─⊱ *${prefix}wiki [query]*
Usage : ${prefix}wiki [Masukkan querynya]
╰─⊱ *${prefix}qrcode [optional]*
Usage : ${prefix}qrcode indapk.com [bebas mau diisi apa, diisi link juga boleh]
╰─⊱ *${prefix}ssweb [linkWeb]*
Usage : ${prefix}ssweb https://www.indapk.com
║
╠══✪〘 NSFW 〙✪═══════════
║
╰─⊱ *${prefix}randomhentai* _[Fitur khusus VIP]_
Usage : ${prefix}randomhentai
╰─⊱ *${prefix}hentai* _[Fitur khusus VIP]_
Usage : ${prefix}hentai
╰─⊱ *${prefix}blowjob* _[Fitur khusus VIP]_
Usage : ${prefix}blowjob
╰─⊱ *${prefix}nsfwtrap* _[Fitur khusus VIP]_
Usage : ${prefix}nsfwtrap _[Fitur khusus VIP]_
╰─⊱ *${prefix}kodenuklir2*
Usage : ${prefix}kodenuklir2
╰─⊱ *${prefix}kodenuklir*
Usage : ${prefix}kodenuklir
╰─⊱ *${prefix}nekopoi* _[Fitur khusus VIP]_
Usage : ${prefix}nekopoi
╰─⊱  *${prefix}indo(1-25)* __[Fitur khusus VIP]__
Usage : ${prefix}indo23 [Masukkan angkanya 1 sampai 25]
║
╠══✪〘 User 〙✪═══════════
║
╰─⊱ *${prefix}s [replay gambar]*
Usage : ${prefix}s Replay gambar atau masukin gambar
╰─⊱ *${prefix}toimg [replay sticker]*
Usage : ${prefix}toimg Replay Stickernya
╰─⊱  *${prefix}tagme*
Usage : ${prefix}tagme
╰─⊱  *${prefix}groupinfo*
Usage : ${prefix}groupinfo
╰─⊱  *${prefix}infogc*
Usage : ${prefix}infogc
╰─⊱  *${prefix}linkgc*
Usage : ${prefix}linkgc
╰─⊱ *${prefix}dadu*
Usage : ${prefix}dadu
╰─⊱ *${prefix}ocr [gambar]*
Usage : ${prefix}ocr [Masukin gambarnya]
╰─⊱ *${prefix}meme*
Usage : ${prefix}meme
╰─⊱ *${prefix}testime*
Usage : ${prefix}testime
╰─⊱ *${prefix}hobby*
Usage : ${prefix}hobby Masukkan teksnya
╰─⊱ *${prefix}slap*
Usage : ${prefix}slap
╰─⊱ *${prefix}beritahoax*
Usage : ${prefix}beritahoax
╰─⊱ *${prefix}watak*
Usage : ${prefix}watak
╰─⊱ *${prefix}artinama* [nama]
Usage : ${prefix}artinama anggaputrajn [Masukin nama]
╰─⊱ *${prefix}listsurah*
Usage : ${prefix}listsurah
╰─⊱ *${prefix}fitnah [@tag|pesan|balasanbot]*
Usage : ${prefix}fitnah Tag|Pesannya|Balasan botnya
╰─⊱ *${prefix}viplist*
Usage : ${prefix}viplist
╰─⊱ *${prefix}tentangindapk*
Usage : ${prefix}tentangindapk
╰─⊱ *${prefix}iklan*
Usage : ${prefix}iklan
╰─⊱ *${prefix}runtime*
Usage : ${prefix}runtime
╰─⊱ *${prefix}infonomor*
Usage : ${prefix}infonomor 082286344446 [Masukkan nomornya]
╰─⊱ *${prefix}wame*
Usage : ${prefix}wame
╰─⊱ *${prefix}snk*
Usage : ${prefix}snk
║
╠═══✪〘 ANIME 〙✪═══════════
║
╰─⊱ *${prefix}animesaran*
Usage : ${prefix}animesaran
╰─⊱ *${prefix}cry*
Usage : ${prefix}cry
╰─⊱ *${prefix}kiss*
Usage : ${prefix}kiss
╰─⊱ *${prefix}randomhug*
Usage : ${prefix}randomhug
╰─⊱ *${prefix}randomanime*
Usage : ${prefix}randomanime
╰─⊱ *${prefix}animerandom*
Usage : ${prefix}animerandom
╰─⊱ *${prefix}ranime*
Usage : ${prefix}ranime
╰─⊱ *${prefix}waifu*
Usage : ${prefix}waifu
╰─⊱ *${prefix}waifu2*
Usage : ${prefix}waifu2
╰─⊱ *${prefix}waifu3*
Usage : ${prefix}waifu3
╰─⊱ *${prefix}nekonime*
Usage : ${prefix}nekonime
[Command yg dapat digunakan : ${prefix}nekonime, ${prefix}randomnekonime]
╰─⊱ *${prefix}scan* _[Fitur khusus VIP]_
Usage : ${prefix}scan upload gambar screenshot anime yg ingin di scan [Pastikan gambar screenshotnya jelas ya!]
╰─⊱ *${prefix}pokemon*
Usage : ${prefix}pokemon
║
╠═══✪〘 ANIMALS 〙✪═══════════
║
╰─⊱ *${prefix}anjing*
Usage : ${prefix}anjing

▣══─⊱ 【 𝑅𝑈𝑁𝑇𝐼𝑀𝐸 】 ⊰─══
║
╰─⊱ *STATUS BOT: Online*
╭─⊱ BOT ON: *24JAM*
║
╠═════✪
║Ketik *${prefix}kegunaanbot* untuk melihat list informasi tentang  BOT
║Ketik *${prefix}owner* untuk melihat kontak owner
║Mau donasi? 082286344446(Gopay)
║➤Report Bug : *${prefix}reportbug*
║Jika tidak ingin donasi bantu Follow Ig Dan Fanspage aja kak 
║ _instagram.com/indapk_
║ _facebook.com/indapk_
▣══─ ⸨ BOT INDapk © 2021 ⸩ ─══▣`
}
exports.help = help
