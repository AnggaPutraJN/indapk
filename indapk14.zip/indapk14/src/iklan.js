const iklan = () => { 
	return `           
╔══✪〘 IKLAN 〙✪════════════
╠═══════════════════════════
╠➥ *Situs*
╠➥ *Situs Download Game : https://www.indapk.com*
╠➥ *Situs Download Doujin 1 : https://indmangapdf.blogspot.com*
╠➥ *Situs Download Film : https://indxfilm.blogspot.com*
╠═══════════════════════════
╠➥ *Aplikasi*
╠➥ *Aplikasi INDapk: https://drive.google.com/file/d/1AwyIZWyAALcxoBDw3U4lhBqP9wEJU0Sw/view?usp=sharing*
╠➥ *Aplikasi INDMangaPDF: https://drive.google.com/file/d/1UdFbVE4FIW_9MKRvAwS9y2TTnXsiEz2s/view?usp=sharing*
╠═══════════════════════════
╠➥ *Grup*
╠➥ *Join Grup WA Game : https://chat.whatsapp.com/Et6CVorLr5D3ILDkMlE6jW*
╠➥ *Join Grup WA Doujin 1 : https://chat.whatsapp.com/GddnwqWKVzSLhrr9ikY9wE*
╠➥ *Join Grup WA Doujin 2 : https://chat.whatsapp.com/G4P1tpV1MNd67efeMAEoof*
╠➥ *Join Grup Tele Doujin : https://t.me/joinchat/GqU9FrenXWMUAaBQ*
╠═══════════════════════════
╚═〘  BOT INDapk 〙
`
}
exports.iklan = iklan