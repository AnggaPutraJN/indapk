const modapk = () => { 
	return `
	*Mod Game Dan Aplikasi*
• Ingin mendownload sesuatu?


👾 https://www.indapk.com
🔰 -----[ *POWERED BY INDapk ]----- 🔰
`
}
exports.modapk = modapk