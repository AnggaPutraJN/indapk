const aplikasimod = (prefix) => { 
	return `
╔══✪〘 APK MOD 〙✪════════════
║
╠➥ *${prefix}emulator*
╠➥ *${prefix}aplikasi*
╠═══════════════════════════
〘  BOT INDapk 〙

	`
}
exports.aplikasimod = aplikasimod