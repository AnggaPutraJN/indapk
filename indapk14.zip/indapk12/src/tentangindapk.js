const tentangindapk = () => { 
	return `       
❦═─⊱〘👾Tentang👾〙⊰══
*INDapk* adalah layanan aplikasi untuk mendownload hampir semua game android,&nbsp; game roms,film/movie, dan aplikasi premium secara gratis
aplikasinya juga tiap hari update semua jenis game maupun aplikasi premium
aplikasi ini mempermudah kan kalian untuk mencari game-game favorite kalian, ataupun game-game berbayar yang ada di playstore, kalian bisa download di aplikasi ini secara free (gratis)
kalian juga akan mendapatkan notifikasi saat ada update-tan atau game baru, jadi kalian gak bakalan ketinggalan info-info seputar game
Request game akan di proses secepat mungkin dan akan mendapatkan notifikasi dari gmail agan sendiri saat requestnya sudah siap atau sudah ada di web atau aplikasi INDapk
================
*Spesifikasi Aplikasi :*
Diperlukan : 4.0+ atau lebih tinggi
================

Link Aplikasi : https://drive.google.com/file/d/1AwyIZWyAALcxoBDw3U4lhBqP9wEJU0Sw/view?usp=sharing

❦═─⊱〘👾BOT INDapk👾〙⊰══
`
    }
exports.tentangindapk = tentangindapk
