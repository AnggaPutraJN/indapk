const daftarvip = (prefix) => { 
	return `
	
*Owner BOT :*
_wa.me/082286344446 atau ketik *${prefix}owner*

*NOTE :*
Hanya owner yang bisa menggunakan VIP !!!

*GRUP WHATSAPP BOT :*
_https://chat.whatsapp.com/Et6CVorLr5D3ILDkMlE6jW_

*Situs :*
_https://www.indapk.com_ 
 `
}
exports.daftarvip = daftarvip