const help = (prefix) => { 
	return `
❦═─⊱〘 𝐼𝑁𝐹𝑂 〙⊰══
║
╰─⊱ BOT By INDapk
║
▣═─⊱【 TIPS 】⊰─══
║ 
╰─⊱ *${prefix}kegunaanbot*
║
▣═─⊱【 𝑴𝑬𝑵𝑼 𝑺𝑰𝑴𝑷𝑳𝑬 】⊰─══
║ 
╭─⊱*${prefix}listmenu*
║
▣═─⊱【 𝐿𝐼𝑆𝑇 𝑀𝐸𝑁𝑈 】⊰─══
║
╰─⊱ *${prefix}ownermenu*
╭─⊱ *${prefix}adminmenu*
  ╰─⊱ *${prefix}nsfwmenu*
  ╰─⊱ *${prefix}funmenu*
  ╰─⊱ *${prefix}mediamenu*
  ╰─⊱ *${prefix} makermenu*
  ╰─⊱ *${prefix}vipmenu*
  ╰─⊱ *${prefix}kerangmenu*
╰─⊱ *${prefix}animemenu*
╭─⊱ *${prefix}othermenu*
║
║
▣═══─⊱【 𝑂𝑇𝐻𝐸𝑅 】⊰─═══
║
╭─⊱ *${prefix}setprefix [mengubah simbol tag bot]*
  ╰─⊱ *${prefix}bugreport [teksmu]*
  ╰─⊱ *${prefix}listblock*
  ╰─⊱ *${prefix}iklan*
  ╰─⊱ *${prefix}runtime*
  ╰─⊱ *${prefix}rules*
  ╰─⊱ *${prefix}tentangindapk*
  ╰─⊱ *${prefix}cekvip*
  ╰─⊱ *${prefix}daftarvip*
  ╰─⊱ *${prefix}addvip*
  ╰─⊱ *${prefix}dellvip*
  ╰─⊱ *${prefix}snk*
  ╰─⊱ *${prefix}premiumlist*
  ╰─⊱ *${prefix}donate*
╰─⊱ *${prefix}ping*
╭─⊱ *${prefix}owner*
║
▣══─⊱ 【 𝑅𝑈𝑁𝑇𝐼𝑀𝐸 】 ⊰─══
║
╰─⊱ *STATUS BOT: Online*
╭─⊱ BOT ON: *24JAM *
║
▣══─ ⸨ BOT INDapk ⸩ ─══▣`
}
exports.help = help
