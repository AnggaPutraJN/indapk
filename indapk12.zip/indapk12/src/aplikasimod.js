const gamingmenu = (prefix) => { 
	return `
╔══✪〘 APK MOD 〙✪════════════
║
╠➥ *${prefix}emulator*
╠➥ *${prefix}aplikasi*
╠═══════════════════════════
〘  BOT INDapk 〙

	`
}
exports.gamingmenu = gamingmenu