const gamingmenu = (prefix) => { 
	return `
╔══✪〘 GAMING ROOM 〙✪════════════
║
╠➥ *${prefix}menurom*
╠➥ *${prefix}gamemod*
╠═══════════════════════════
〘  BOT INDapk 〙

	`
}
exports.gamingmenu = gamingmenu