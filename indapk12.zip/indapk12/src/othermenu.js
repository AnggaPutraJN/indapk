const othermenu = (prefix) => { 
	return `
╔══✪〘 OTHER 〙✪══
║
╰─⊱ *${prefix}s [[replay gambar]*
╰─⊱ *${prefix}sticker [[replay gambar]*
╰─⊱ *${prefix}stiker [[replay gambar]*
╰─⊱ *${prefix}ttp [teks]*
╰─⊱ *${prefix}toimg [replay sticker]*
╰─⊱ *${prefix}pokemon*
╰─⊱ *${prefix}dadu*
╰─⊱ *${prefix}ocr [gambar]*
╰─⊱ *${prefix}meme*
╰─⊱ *${prefix}testime*
╰─⊱ *${prefix}ttp [teks]*
╰─⊱ *${prefix}hobby*
╰─⊱ *${prefix}slap*
╰─⊱ *${prefix}beritahoax*
╰─⊱ *${prefix}watak*
╰─⊱ *${prefix}jsholat [daerah]*
╰─⊱ *${prefix}report*
╰─⊱ *${prefix}cekjodoh* [nama]
╰─⊱ *${prefix}artinama* [indapk]
╰─⊱ *${prefix}listsurah*
╰─⊱ *${prefix}fitnah [@tag|pesan|balasanbot]]*
║
╠═══✪〘 ANIME 〙✪══
║
╰─⊱ *${prefix}randomanime*
╰─⊱ *${prefix}animerandom*
╰─⊱ *${prefix}ranime*
╰─⊱ *${prefix}waifu*
╰─⊱ *${prefix}waifu2*
╰─⊱ *${prefix}waifu3*
╰─⊱ *${prefix}nekonime*
╰─⊱ *${prefix}wait*
╰─⊱ *${prefix}pokemon*

║
╠═══✪〘 ANIMALS 〙✪══
║
╰─⊱ *${prefix}anjing*
║
╚═ Ketik *${prefix}info* untuk melihat list informasi tentang bot
       Ketik *${prefix}owner* untuk melihat kontak owner
         Mau donasi? 082286344446(Gopay)
         Jika tidak ingin donasi bantu Follow Ig aja kak 
         _instagram.com/indapk
    _* BOT INDapk © 2021*_
║
╚═〘 BOT INDapk 〙`
}
exports.othermenu = othermenu