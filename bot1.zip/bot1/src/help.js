const help = (prefix) => { 
	return `
❦═─⊱〘 𝐼𝑁𝐹𝑂 〙⊰══
║
╰─⊱ BOT By INDapk
║
▣═─⊱【 𝐿𝐼𝑆𝑇 𝑀𝐸𝑁𝑈 】⊰─══
║
╰─⊱ *${prefix}ownermenu*
Usage : ${prefix}ownermenu
╭─⊱ *${prefix}adminmenu*
Usage : ${prefix}adminmenu
  ╰─⊱ *${prefix}nsfwmenu*
Usage : ${prefix}nsfwmenu
  ╰─⊱ *${prefix}funmenu*
Usage : ${prefix}funmenu
  ╰─⊱ *${prefix}mediamenu*
Usage : ${prefix}mediamenu
  ╰─⊱ *${prefix} makermenu*
Usage : ${prefix}makermenu
  ╰─⊱ *${prefix}vipmenu*
Usage : ${prefix}vipmenu
  ╰─⊱ *${prefix}kerangmenu*
Usage : ${prefix}kerangmenu
╰─⊱ *${prefix}animemenu*
Usage : ${prefix}animemenu
╭─⊱ *${prefix}othermenu*
Usage : ${prefix}othermenu
║
▣═─⊱【 Gaming Menu 】⊰─══ *[NEW Fitur]*
║
╰─⊱ *${prefix}gamingmenu*
Usage : ${prefix}gamingmenu
╭─⊱ *${prefix}aplikasimod*
Usage : ${prefix}aplikasimod
║
▣═══─⊱【 USER 】⊰─═══
║
╭─⊱ *${prefix}setprefix*
Usage : ${prefix}setprefix . atau !
  ╰─⊱ *${prefix}listblock*
Usage : ${prefix}listblock
  ╰─⊱ *${prefix}iklan*
Usage : ${prefix}iklan
  ╰─⊱ *${prefix}runtime*
Usage : ${prefix}runtime
  ╰─⊱ *${prefix}rules*
Usage : ${prefix}rules
  ╰─⊱ *${prefix}tentangindapk*
Usage : ${prefix}tentangindapk
  ╰─⊱ *${prefix}cekvip*
Usage : ${prefix}cekvip
  ╰─⊱ *${prefix}daftarvip*
Usage : ${prefix}daftarvip
  ╰─⊱ *${prefix}addvip*
Usage : ${prefix}addvip Tag nama yang mau di jadikan vip (fitur ini hanya untuk owner)
  ╰─⊱ *${prefix}dellvip*
Usage : ${prefix}dellvip Tag nama yang mau di hapus dari vip (fitur ini hanya untuk owner)
  ╰─⊱ *${prefix}snk*
Usage : ${prefix}snk
  ╰─⊱ *${prefix}premiumlist*
Usage : ${prefix}premiumlist
  ╰─⊱ *${prefix}donate*
Usage : ${prefix}donate atau ${prefix}donasi
╰─⊱ *${prefix}ping*
Usage : ${prefix}ping
╭─⊱ *${prefix}owner*
Usage : ${prefix}owner atau ${prefix}admin
║
▣═─⊱【 TIPS 】⊰─══
║
╰─⊱ *${prefix}kegunaanbot*
Usage : *${prefix}kegunaanbot
╰─⊱ *${prefix}rules*
Usage : *${prefix}rules
╭─⊱*${prefix}listmenu*
Usage : *${prefix}listmenu [Menunya Lebih Lengkap!]
║
▣═─⊱【 𝑴𝑬𝑵𝑼 𝑺𝑰𝑴𝑷𝑳𝑬 】⊰─══
║
╭─⊱*${prefix}listmenu*
Usage : *${prefix}listmenu [Menunya Lebih Lengkap!]
║
▣══─⊱ 【 𝑅𝑈𝑁𝑇𝐼𝑀𝐸 】 ⊰─══
║
╰─⊱ *STATUS BOT: Online*
╭─⊱ BOT ON: *24JAM *
║
▣══─ ⸨ BOT INDapk © 2021 ⸩ ─══▣`
}
exports.help = help
