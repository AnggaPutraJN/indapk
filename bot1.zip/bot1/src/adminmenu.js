const adminmenu = (prefix) => { 
	return `
✎═─⊱〘 𝐴𝐷𝑀𝐼𝑁 𝑀𝐸𝑁𝑈 〙⊰══
║
║
║
║
╰─⊱ *${prefix}snk*
Usage : ${prefix}snk
╰─⊱ *${prefix}tagall*
Usage : ${prefix}tagall [Fitur ini hanya untuk Admin Grup]
╰─⊱  *${prefix}otagall*
Usage : ${prefix}otagall [Fitur ini hanya untuk Admin Grup]
╰─⊱  *${prefix}otagall2*
Usage : ${prefix}otagall2 [Fitur ini hanya untuk Admin Grup]
╰─⊱  *${prefix}setdesc*
Usage : ${prefix}setdesc Masukkan Teksnya Untuk mengubah deskripsi grup [Fitur ini hanya untuk Admin Grup]
╰─⊱  *${prefix}setname*
Usage : ${prefix}setname Masukkan Teksnya Untuk mengubah nama grup [Fitur ini hanya untuk Admin Grup]
╰─⊱  *${prefix}kick* [tag]
Usage : ${prefix}kick Tag Member yang ingin di kick [Fitur ini hanya untuk Admin Grup]
╰─⊱  *${prefix}add* [628xxx]
Usage : ${prefix}add 628xxx Masukin nomor target [Fitur ini hanya untuk Admin Grup]
╰─⊱  *${prefix}promote* [tag]
Usage : ${prefix}promote Tag member untuk dijadikan admin [Fitur ini hanya untuk Admin Grup]
╰─⊱  *${prefix}demote* [tag]
Usage : ${prefix}demote Tag admin untuk tidak dijadikan admin lagi [Fitur ini hanya untuk Admin Grup]
╰─⊱  *${prefix}group* [buka]
Usage : ${prefix}group buka
╰─⊱  *${prefix}group* [tutup]
Usage : ${prefix}group tutup
╰─⊱  *${prefix}linkgc*
Usage : ${prefix}linkgc
╰─⊱  *${prefix}setpp*
Usage : ${prefix}setpp Reply foto atau masukin fotonya
╰─⊱  *${prefix}infogc*
Usage : ${prefix}infogc
╰─⊱  *${prefix}groupinfo*
Usage : ${prefix}groupinfo
╰─⊱  *${prefix}tagme*
Usage : ${prefix}tagme
╰─⊱  *${prefix}nsfw* [1/0]
Usage : ${prefix}nsfw 1 untuk mengaktifkan fitur nsfw dan ${prefix}nsfw 0 untuk nonaktifkan fitur
╰─⊱  *${prefix}anime* [1/0]
Usage : ${prefix}anime 1 untuk mengaktifkan fitur anime dan ${prefix}anime 0 untuk nonaktifkan fitur
╰─⊱  *${prefix}simih* [1/0]
Usage : ${prefix}simih 1 untuk mengaktifkan fitur simih dan ${prefix}simih 0 untuk nonaktifkan fitur
╰─⊱  *${prefix}welcome* [1/0]
Usage : ${prefix}welcome 1 Untuk mengaktifkan welcome pada grup dan ${prefix}welcome 0 untuk menonaktifkan
╰─⊱  *${prefix}edotensei*
Usage : ${prefix}edotensei
╰─⊱  *${prefix}listadmins*
Usage : ${prefix}listadmins
╰─⊱  *${prefix}ping*
Usage : ${prefix}ping
╰─⊱ *${prefix}iklan*
Usage : ${prefix}iklan
║
║
║
║
✎═─⊱〘 BOT INDapk © 2021 〙⊰══`
}
exports.adminmenu = adminmenu