const menurom = (prefix) => { 
	return `
╔══✪〘 ROM EMULATOR 〙✪════════════
║		*[NEW Fitur]*
╠═══════════════════════════
╠➥ *${prefix}ppsspp*
Usage : ${prefix}ppsspp
╠➥ *${prefix}ppssppringan*
Usage : ${prefix}ppssppringan
╠➥ *${prefix}ps1*
Usage : ${prefix}ps1
╠➥ *${prefix}ps2*
Usage : ${prefix}ps2
╠➥ *${prefix}gamecube*
Usage : ${prefix}gamecube
╠➥ *${prefix}wii*
Usage : ${prefix}wii
╠═══════════════════════════
〘 BOT INDapk © 2021 〙

	`
}
exports.menurom = menurom