const vipmenu = (prefix) => { 
	return `            
	
╔══✪〘 VIP USER 〙✪══
║
╰─⊱ *${prefix}ytmp3 [link]*
Usage : ${prefix}ytmp3 Link youtubenya
╰─⊱ *${prefix}hidetag2*
Usage : ${prefix}hidetag2
╰─⊱ *${prefix}joox [lagu]*
Usage : ${prefix}joox Impossible [Masukkan Judul lagunya]
╰─⊱ *${prefix}setprefix*
Usage : ${prefix}setprefix ! atau . [Untuk mengganti command]
╰─⊱ *${prefix}tomp3 [replay video]*
Usage : ${prefix}tomp3 Replay Videonya
╰─⊱  *${prefix}randomanime*
Usage : ${prefix}randomanime
╰─⊱  *${prefix}randomhentai*
Usage : ${prefix}randomhentai
╰─⊱  *${prefix}nsfwloli*
Usage : ${prefix}nsfwloli
╰─⊱  *${prefix}nsfwblowjob*
Usage : ${prefix}nsfwblowjob
╰─⊱  *${prefix}nsfwneko*
Usage : ${prefix}nsfwneko
╰─⊱  *${prefix}nsfwtrap*
Usage : ${prefix}nsfwtrap
╰─⊱  *${prefix}indohot*
Usage : ${prefix}indohot
╰─⊱  *${prefix}otagall2*
Usage : ${prefix}otagall2
╰─⊱  *${prefix}otagall3*
Usage : ${prefix}otagall3
╰─⊱  *${prefix}hidetag5*
Usage : ${prefix}hidetag5
╰─⊱  *${prefix}indo(1-25)*
Usage : ${prefix}indo23 [Masukkan angkanya 1 sampai 25]
║
╚══✪〘 BOT INDapk © 2021 〙✪══
`
}
exports.vipmenu = vipmenu