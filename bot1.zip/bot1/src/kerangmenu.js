const kerangmenu = (prefix) => { 
	return `
╔══✪〘 KERANG 〙✪══
║
║╰─⊱ *${prefix}apakah [optional]*
Usage : ${prefix}apakah Masukkan textnya bebas
║╰─⊱ *${prefix}rate [optional]*
Usage : ${prefix}rate Masukkan textnya bebas
║╰─⊱ *${prefix}bisakah [optional]*
Usage : ${prefix}bisakah Masukkan textnya bebas
║╰─⊱ *${prefix}kapankah [optional]*
Usage : ${prefix}kapankah Masukkan textnya bebas
║╰─⊱ *${prefix}gantengcek*
Usage : ${prefix}
║╰─⊱ *${prefix}toxic*
Usage : ${prefix}toxic
║╰─⊱ *${prefix}cantikcek*
Usage : ${prefix}cantikcek
║╰─⊱ *${prefix}gay [tag]*
Usage : ${prefix}gay Tag orangnya
║
╚═〘 BOT INDapk © 2021 〙`
}
exports.kerangmenu = kerangmenu