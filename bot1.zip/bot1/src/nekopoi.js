const nekopoi = () => { 
	return `
╔══✪〘 NEKOPOI 〙✪═══════════
║
║Mau akses/nonton nekopoi tanpa download vpn? Klik link dibawah ini lalu scroll kebawah terus ketik setuju & hubungkan.
║
║https://www.hidemyass-freeproxy.com/proxy/id-id/aHR0cHM6Ly9uZWtvcG9pLmNhcmUv
║
║*Selamat Menonton*
║
╚═〘 BOT INDapk © 2021 〙
`
}
exports.nekopoi = nekopoi