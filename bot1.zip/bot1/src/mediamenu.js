const mediamenu = (prefix) => { 
	return `

╔══✪〘 MEDIA 〙✪══
║
╰─⊱ *${prefix}ytkomen* [Nama|Teksnya]
Usage : ${prefix}ytkomen Masukkan nama kalian | Komentar atau Text bebas
╰─⊱ *${prefix}lirik* [judul lagu]
Usage : ${prefix}lirik Impossible
╰─⊱ *${prefix}chord* [judul lagu]
Usage : ${prefix}chord Impossible
╰─⊱ *${prefix}url2img* [link]
Usage : ${prefix}url2img Mobile | Linknya [Tipenya ada Desktop, Tablet, Mobile]
╰─⊱ *${prefix}fototiktok* [username]
Usage : ${prefix}fototiktok anggaputrajn [Masukkan id usernamenya]
╰─⊱ *${prefix}map* [kota]
Usage : ${prefix}map Makassar [Masukkan nama kotanya]
╰─⊱ *${prefix}kbbi* [kamus]
Usage : ${prefix}kbbi Masukkan kamusnya
╰─⊱ *${prefix}infocuaca* [kota]
Usage : ${prefix}infocuaca Makassar [Masukkan nama kotanya]
╰─⊱ *${prefix}artinama [nama]*
Usage : ${prefix}artinama anggaputrajn [Masukkan nama]
╰─⊱ *${prefix}resepmasakan [optional]*
Usage : ${prefix}resepmasakan ayam goreng [Bebas]
╰─⊱ *${prefix}tts [kode bhs] [teks]*
Usage : ${prefix}tts id Aku ganteng [Kode bahasa untuk bahasa Indonesia, Ketik ${prefix}kodebhs untuk cek kode-kode bahasanya]
╰─⊱ *${prefix}tiktokstalk [@username]*
Usage : ${prefix}tiktokstalk anggaputrajn [Masukkan id usernamenya]
╰─⊱ *${prefix}wiki [query]*
Usage : ${prefix}wiki [Masukkan querynya]
╰─⊱ *${prefix}qrcode [optional]*
Usage : ${prefix}qrcode indapk.com [bebas mau diisi apa, diisi link juga boleh]
╰─⊱ *${prefix}ssweb [linkWeb]*
Usage : ${prefix}ssweb https://www.indapk.com
╰─⊱ *${prefix}animesaran*
Usage : ${prefix}animesaran
Usage : ${prefix}animesaran
║
╚═〘 BOT INDapk © 2021 〙`
}
exports.mediamenu = mediamenu