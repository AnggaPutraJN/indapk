const ownermenu = (prefix) => { 
	return `
	
╔══✪〘 OWNER 〙✪══
║
╰─⊱ *${prefix}block*
Usage : ${prefix}block 62858xxxxx (TAG)
╰─⊱ *${prefix}unblock*
Usage : ${prefix}unblock 62858xxxxx (TAG)
╰─⊱ *${prefix}promote*
Usage : ${prefix}promote Tag member target yang ingin dijadikan admin!
╰─⊱ *${prefix}demote*
Usage : ${prefix}demote Tag admin target yang tidak ingin dijadikan admin!
╰─⊱  *${prefix}leave*
Usage : ${prefix}leave
╰─⊱  *${prefix}clearall*
Usage : ${prefix}clearall
╰─⊱  *${prefix}clone*
Usage : ${prefix}clone Tag target yang ingin di clone
╰─⊱  *${prefix}hidetag*
Usage : ${prefix}hidetag
╰─⊱  *${prefix}hidetag2*
Usage : ${prefix}hidetag2
╰─⊱  *${prefix}setprefix*
Usage : ${prefix}setprefix . atau !〘 Fitur ini hanya digunakan untuk owner 〙
╰─⊱  *${prefix}unban*
Usage : ${prefix}unban Tag namanya 〘 Fitur ini hanya digunakan untuk owner 〙
╰─⊱  *${prefix}ban*
Usage : ${prefix}ban Tag namanya〘 Fitur ini hanya digunakan untuk owner 〙
╰─⊱ *${prefix}runtime*
Usage : ${prefix}runtime
╰─⊱ *${prefix}iklan*
Usage : ${prefix}iklan
╰─⊱ *${prefix}turnoff*
Usage : ${prefix}turnoff Replay gambarnya
╰─⊱ *${prefix}ban*
Usage : ${prefix}ban tag member yang ingin di ban
╰─⊱ *${prefix}unban*
Usage : ${prefix}unban tag member yang ingin di unban
║
╚═〘 BOT INDapk © 2021 〙`
}
exports.ownermenu = ownermenu