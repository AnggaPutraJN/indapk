const listmenu = (prefix) => { 
	return `                 
╔══✪〘 OWNER 〙✪═══════════
║
╰─⊱ *${prefix}block*
Usage : ${prefix}block 62858xxxxx (TAG)
╰─⊱ *${prefix}unblock*
Usage : ${prefix}unblock 62858xxxxx (TAG)
╰─⊱ *${prefix}promote*
Usage : ${prefix}promote Tag member target yang ingin dijadikan admin!
╰─⊱ *${prefix}demote*
Usage : ${prefix}demote Tag admin target yang tidak ingin dijadikan admin!
╰─⊱  *${prefix}leave*
Usage : ${prefix}leave
╰─⊱  *${prefix}clearall*
Usage : ${prefix}clearall
╰─⊱  *${prefix}clone*
Usage : ${prefix}clone Tag target yang ingin di clone
╰─⊱  *${prefix}hidetag*
Usage : ${prefix}hidetag
╰─⊱  *${prefix}hidetag2*
Usage : ${prefix}hidetag2
╰─⊱  *${prefix}setprefix*
Usage : ${prefix}setprefix . atau !〘 Fitur ini hanya digunakan untuk owner 〙
╰─⊱  *${prefix}unban*
Usage : ${prefix}unban Tag namanya 〘 Fitur ini hanya digunakan untuk owner 〙
╰─⊱  *${prefix}ban*
Usage : ${prefix}ban Tag namanya〘 Fitur ini hanya digunakan untuk owner 〙
╰─⊱ *${prefix}runtime*
Usage : ${prefix}runtime
╰─⊱ *${prefix}iklan*
Usage : ${prefix}iklan
╰─⊱ *${prefix}turnoff*
Usage : ${prefix}turnoff Replay gambarnya
╰─⊱ *${prefix}ban*
Usage : ${prefix}ban tag member yang ingin di ban
╰─⊱ *${prefix}unban*
Usage : ${prefix}unban tag member yang ingin di unban
║
╠══✪〘 ADMIN 〙✪═══════════
║
╰─⊱ *${prefix}premiumlist*
Usage : ${prefix}premiumlist
╰─⊱ *${prefix}tentangindapk*
Usage : ${prefix}tentangindapk
╰─⊱ *${prefix}snk*
Usage : ${prefix}snk
╰─⊱ *${prefix}tagall*
Usage : ${prefix}tagall [Fitur ini hanya untuk Admin Grup]
╰─⊱  *${prefix}otagall*
Usage : ${prefix}otagall [Fitur ini hanya untuk Admin Grup]
╰─⊱  *${prefix}otagall2*
Usage : ${prefix}otagall2 [Fitur ini hanya untuk Admin Grup]
╰─⊱  *${prefix}setdesc*
Usage : ${prefix}setdesc Masukkan Teksnya Untuk mengubah deskripsi grup [Fitur ini hanya untuk Admin Grup]
╰─⊱  *${prefix}setname*
Usage : ${prefix}setname Masukkan Teksnya Untuk mengubah nama grup [Fitur ini hanya untuk Admin Grup]
╰─⊱  *${prefix}kick* [tag]
Usage : ${prefix}kick Tag Member yang ingin di kick [Fitur ini hanya untuk Admin Grup]
╰─⊱  *${prefix}add* [628xxx]
Usage : ${prefix}add 628xxx Masukin nomor target [Fitur ini hanya untuk Admin Grup]
╰─⊱  *${prefix}promote* [tag]
Usage : ${prefix}promote Tag member untuk dijadikan admin [Fitur ini hanya untuk Admin Grup]
╰─⊱  *${prefix}demote* [tag]
Usage : ${prefix}demote Tag admin untuk tidak dijadikan admin lagi [Fitur ini hanya untuk Admin Grup]
╰─⊱  *${prefix}group* [buka]
Usage : ${prefix}group buka
╰─⊱  *${prefix}group* [tutup]
Usage : ${prefix}group tutup
╰─⊱  *${prefix}linkgc*
Usage : ${prefix}linkgc
╰─⊱  *${prefix}setpp*
Usage : ${prefix}setpp Reply foto atau masukin fotonya
╰─⊱  *${prefix}infogc*
Usage : ${prefix}infogc
╰─⊱  *${prefix}groupinfo*
Usage : ${prefix}groupinfo
╰─⊱  *${prefix}tagme*
Usage : ${prefix}tagme
╰─⊱  *${prefix}nsfw* [1/0]
Usage : ${prefix}nsfw 1 untuk mengaktifkan fitur nsfw dan ${prefix}nsfw 0 untuk nonaktifkan fitur
╰─⊱  *${prefix}anime* [1/0]
Usage : ${prefix}anime 1 untuk mengaktifkan fitur anime dan ${prefix}anime 0 untuk nonaktifkan fitur
╰─⊱  *${prefix}simih* [1/0]
Usage : ${prefix}simih 1 untuk mengaktifkan fitur simih dan ${prefix}simih 0 untuk nonaktifkan fitur
╰─⊱  *${prefix}welcome* [1/0]
Usage : ${prefix}welcome 1 Untuk mengaktifkan welcome pada grup dan ${prefix}welcome 0 untuk menonaktifkan
╰─⊱  *${prefix}edotensei*
Usage : ${prefix}edotensei
╰─⊱  *${prefix}listadmins*
Usage : ${prefix}listadmins
╰─⊱  *${prefix}ping*
Usage : ${prefix}ping
╰─⊱ *${prefix}iklan*
Usage : ${prefix}iklan
║
╠══✪〘 Gaming Menu 〙✪═══ *[NEW Fitur]*
║
╰─⊱ *${prefix}gamingmenu*
Usage : ${prefix}gamingmenu
╰─⊱ *${prefix}aplikasimod*
Usage : ${prefix}aplikasimod
║
╠══✪〘 FUN 〙✪═══════════
║
╰─⊱ *${prefix}truth*
Usage : ${prefix}truth
╰─⊱ *${prefix}dare*
Usage : ${prefix}dare
╰─⊱ *${prefix}pinterest*
Usage : ${prefix}pinterest naruto (masukin aja text bebas)
╰─⊱ *${prefix}syg* [text]
Usage : ${prefix}syg aku ganteng gak [Masukkan text atau pertanyaan]
║
╠══✪〘 KERANG 〙✪═════════
║
╰─⊱ *${prefix}apakah [optional]*
Usage : ${prefix}apakah Masukkan textnya bebas
╰─⊱ *${prefix}rate [optional]*
Usage : ${prefix}rate Masukkan textnya bebas
╰─⊱ *${prefix}bisakah [optional]*
Usage : ${prefix}bisakah Masukkan textnya bebas
╰─⊱ *${prefix}kapankah [optional]*
Usage : ${prefix}kapankah Masukkan textnya bebas
╰─⊱ *${prefix}gantengcek*
Usage : ${prefix}
╰─⊱ *${prefix}toxic*
Usage : ${prefix}toxic
╰─⊱ *${prefix}cantikcek*
Usage : ${prefix}cantikcek
╰─⊱ *${prefix}gay [tag]*
Usage : ${prefix}gay Tag orangnya
║
╠══✪〘 MAKER 〙✪═══════════*[NEW Fitur]*
║
╰─⊱ *${prefix}lava* [text]
Usage : ${prefix}lava AnggaPutraJN [Masukkan nama kalian atau bebas mau text apa aja]
╰─⊱ *${prefix}firework* [text]
Usage : ${prefix}firework AnggaPutraJN [Masukkan nama kalian atau bebas mau text apa aja]
╰─⊱ *${prefix}blood* [text]
Usage : ${prefix}blood AnggaPutraJN [Masukkan nama kalian atau bebas mau text apa aja]
╰─⊱ *${prefix}sumery* [text]
Usage : ${prefix}sumery AnggaPutraJN [Masukkan nama kalian atau bebas mau text apa aja]
╰─⊱ *${prefix}toxic2* [text]
Usage : ${prefix}toxic2 AnggaPutraJN [Masukkan nama kalian atau bebas mau text apa aja]
╰─⊱ *${prefix}neontext* [text]
Usage : ${prefix}neontext AnggaPutraJN [Masukkan nama kalian atau bebas mau text apa aja]
╰─⊱ *${prefix}grenneon* [text]
Usage : ${prefix}grenneon AnggaPutraJN [Masukkan nama kalian atau bebas mau text apa aja]
╰─⊱ *${prefix}dropwater* [text]
Usage : ${prefix}dropwater AnggaPutraJN [Masukkan nama kalian atau bebas mau text apa aja]
╰─⊱ *${prefix}metaldark* [text]
Usage : ${prefix}metaldark AnggaPutraJN [Masukkan nama kalian atau bebas mau text apa aja]
╰─⊱ *${prefix}sandwrite* [text]
Usage : ${prefix}sandwrite AnggaPutraJN [Masukkan nama kalian atau bebas mau text apa aja]
╰─⊱ *${prefix}summer* [text]
Usage : ${prefix}summer AnggaPutraJN [Masukkan nama kalian atau bebas mau text apa aja]
╰─⊱ *${prefix}shadow* [text]
Usage : ${prefix}shadow AnggaPutraJN [Masukkan nama kalian atau bebas mau text apa aja]
║
╠══✪〘 MEDIA 〙✪═══════════
║
╰─⊱ *${prefix}ytkomen* [Nama|Teksnya]
Usage : ${prefix}ytkomen Masukkan nama kalian | Komentar atau Text bebas
╰─⊱ *${prefix}lirik* [judul lagu]
Usage : ${prefix}lirik Impossible
╰─⊱ *${prefix}chord* [judul lagu]
Usage : ${prefix}chord Impossible
╰─⊱ *${prefix}url2img* [link]
Usage : ${prefix}url2img Mobile | Linknya [Tipenya ada Desktop, Tablet, Mobile]
╰─⊱ *${prefix}fototiktok* [username]
Usage : ${prefix}fototiktok anggaputrajn [Masukkan id usernamenya]
╰─⊱ *${prefix}map* [kota]
Usage : ${prefix}map Makassar [Masukkan nama kotanya]
╰─⊱ *${prefix}kbbi* [kamus]
Usage : ${prefix}kbbi Masukkan kamusnya
╰─⊱ *${prefix}infocuaca* [kota]
Usage : ${prefix}infocuaca Makassar [Masukkan nama kotanya]
╰─⊱ *${prefix}artinama [nama]*
Usage : ${prefix}artinama anggaputrajn [Masukkan nama]
╰─⊱ *${prefix}resepmasakan [optional]*
Usage : ${prefix}resepmasakan ayam goreng [Bebas]
╰─⊱ *${prefix}tts [kode bhs] [teks]*
Usage : ${prefix}tts id Aku ganteng [Kode bahasa untuk bahasa Indonesia, Ketik ${prefix}kodebhs untuk cek kode-kode bahasanya]
╰─⊱ *${prefix}tiktokstalk [@username]*
Usage : ${prefix}tiktokstalk anggaputrajn [Masukkan id usernamenya]
╰─⊱ *${prefix}wiki [query]*
Usage : ${prefix}wiki [Masukkan querynya]
╰─⊱ *${prefix}qrcode [optional]*
Usage : ${prefix}qrcode indapk.com [bebas mau diisi apa, diisi link juga boleh]
╰─⊱ *${prefix}ssweb [linkWeb]*
Usage : ${prefix}ssweb https://www.indapk.com
╰─⊱ *${prefix}animesaran*
Usage : ${prefix}animesaran
║
╠══✪〘 VIP USER 〙✪═══════════
║
╰─⊱ *${prefix}ytmp3 [link]*
Usage : ${prefix}ytmp3 Link youtubenya
╰─⊱ *${prefix}hidetag2*
Usage : ${prefix}hidetag2
╰─⊱ *${prefix}joox [lagu]*
Usage : ${prefix}joox Impossible [Masukkan Judul lagunya]
╰─⊱ *${prefix}setprefix*
Usage : ${prefix}setprefix ! atau . [Untuk mengganti command]
╰─⊱ *${prefix}tomp3 [replay video]*
Usage : ${prefix}tomp3 Replay Videonya
╰─⊱  *${prefix}randomanime*
Usage : ${prefix}randomanime
╰─⊱  *${prefix}randomhentai*
Usage : ${prefix}randomhentai
╰─⊱  *${prefix}nsfwloli*
Usage : ${prefix}nsfwloli
╰─⊱  *${prefix}nsfwblowjob*
Usage : ${prefix}nsfwblowjob
╰─⊱  *${prefix}nsfwneko*
Usage : ${prefix}nsfwneko
╰─⊱  *${prefix}nsfwtrap*
Usage : ${prefix}nsfwtrap
╰─⊱  *${prefix}indohot*
Usage : ${prefix}indohot
╰─⊱  *${prefix}otagall2*
Usage : ${prefix}otagall2
╰─⊱  *${prefix}otagall3*
Usage : ${prefix}otagall3
╰─⊱  *${prefix}hidetag5*
Usage : ${prefix}hidetag5
╰─⊱  *${prefix}indo(1-25)*
Usage : ${prefix}indo23 [Masukkan angkanya 1 sampai 25]
║
╠══✪〘 NSFW 〙✪═══════════
║
╰─⊱ *${prefix}randomhentai*
Usage : ${prefix}randomhentai
╰─⊱ *${prefix}hentai*
Usage : ${prefix}hentai
╰─⊱ *${prefix}nsfwblowjob*
Usage : ${prefix}nsfwblowjob
╰─⊱ *${prefix}nsfwtrap*
Usage : ${prefix}nsfwtrap
╰─⊱ *${prefix}kodenuklir2*
Usage : ${prefix}kodenuklir2
╰─⊱ *${prefix}randomanime*
Usage : ${prefix}randomanime
╰─⊱ *${prefix}cry*
Usage : ${prefix}cry
╰─⊱ *${prefix}kiss*
Usage : ${prefix}kiss
╰─⊱ *${prefix}randomhug*
Usage : ${prefix}randomhug
╰─⊱ *${prefix}nekonime*
Usage : ${prefix}nekonime
╰─⊱ *${prefix}waifu*
Usage : ${prefix}waifu
╰─⊱ *${prefix}waifu2*
Usage : ${prefix}waifu2
╰─⊱ *${prefix}kodenuklir*
Usage : ${prefix}kodenuklir
╰─⊱ *${prefix}nekopoi*
Usage : ${prefix}nekopoi
╰─⊱  *${prefix}indo(1-25)*
Usage : ${prefix}indo23 [Masukkan angkanya 1 sampai 25]
║
╠══✪〘 OTHER 〙✪═══════════
║
╰─⊱ *${prefix}s [replay gambar]*
Usage : ${prefix}s Replay gambar atau masukin gambar
╰─⊱ *${prefix}toimg [replay sticker]*
Usage : ${prefix}toimg Replay Stickernya
╰─⊱ *${prefix}pokemon*
Usage : ${prefix}pokemon
╰─⊱ *${prefix}dadu*
Usage : ${prefix}dadu
╰─⊱ *${prefix}ocr [gambar]*
Usage : ${prefix}ocr [Masukin gambarnya]
╰─⊱ *${prefix}meme*
Usage : ${prefix}meme
╰─⊱ *${prefix}testime*
Usage : ${prefix}testime
╰─⊱ *${prefix}hobby*
Usage : ${prefix}hobby
╰─⊱ *${prefix}slap*
Usage : ${prefix}slap
╰─⊱ *${prefix}beritahoax*
Usage : ${prefix}beritahoax
╰─⊱ *${prefix}watak*
Usage : ${prefix}watak
╰─⊱ *${prefix}jsholat [daerah]*
Usage : ${prefix}jsholat [Masukin daerahnya]
╰─⊱ *${prefix}cekjodoh* [nama]
Usage : ${prefix}cekjodoh anggaputrajn [Masukin nama]
╰─⊱ *${prefix}artinama* [nama]
Usage : ${prefix}artinama anggaputrajn [Masukin nama]
╰─⊱ *${prefix}listsurah*
Usage : ${prefix}listsurah
╰─⊱ *${prefix}fitnah [@tag|pesan|balasanbot]*
Usage : ${prefix}fitnah Tag|Pesannya|Balasan botnya
║
╠═══✪〘 ANIME 〙✪═══════════
║
╰─⊱ *${prefix}randomanime*
Usage : ${prefix}randomanime
╰─⊱ *${prefix}animerandom*
Usage : ${prefix}animerandom
╰─⊱ *${prefix}ranime*
Usage : ${prefix}ranime
╰─⊱ *${prefix}waifu*
Usage : ${prefix}waifu
╰─⊱ *${prefix}waifu2*
Usage : ${prefix}waifu2
╰─⊱ *${prefix}waifu3*
Usage : ${prefix}waifu3
╰─⊱ *${prefix}nekonime*
Usage : ${prefix}nekonime
╰─⊱ *${prefix}wait*
Usage : ${prefix}wait
╰─⊱ *${prefix}pokemon*
Usage : ${prefix}pokemon
║
╠═══✪〘 ANIMALS 〙✪═══════════
║
╰─⊱ *${prefix}anjing*
Usage : ${prefix}anjing
║
╠═════✪
║Ketik *${prefix}kegunaanbot* untuk melihat list informasi tentang indapk bot
║Ketik *${prefix}owner* untuk melihat kontak owner
║Mau donasi? 082286344446(Gopay)
║Jika tidak ingin donasi bantu Follow Ig Dan Fanspage aja kak 
║_instagram.com/indapk
║_facebook.com/indapk
║
✎═─⊱〘 BOT INDapk © 2021 〙⊰══`
}
exports.listmenu = listmenu